/*
 * hardware_tests.h
 *
 * Created: 04.09.2023 15:45:54
 *  Author: jknewall
 */ 


#ifndef HARDWARE_TESTS_H_
#define HARDWARE_TESTS_H_


void SRAM_test(void);
void adc_test(void);


#endif /* HARDWARE_TESTS_H_ */